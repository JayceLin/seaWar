
var Bubble=function(options){
	this.source=options.source;
	this.destination=options.destination;
	this.isDead=false;
	this.collisionContainer={
		Monster:{},
		Bubble:[]
	};
	
}
Bubble.prototype=new Component();
Bubble.prototype.go=function(options){
	//this.spriteSheet=options.spriteSheet
	/*
	this.gotoAndPlay("move");
	this.currentAnimationFrame=0;
	Game.stage.addChild(this);
	Ticker.addListener(this.tickContainer)
	*/
	console.log(this)

};
Bubble.prototype.addCollision=function(options){
	//@@parameters options
	/*
		{
			Monster:{ 
				#MonsterObj
			},
			Bubble:[
				#BubbleObj
			]
		}
	*/
	this.collisionContainer.Monster=options.monsterCollision;

	for(var i=0,len=options.bubbleCollision.length;i<len;i++){
		this.collisionContainer.Bubble.push(options.bubbleCollision[i]);
	}
	
};
Bubble.prototype.defaultTickFun=function(){

	var that=this,
		calculateSpeed=function(){
			console.log(that,"asdf")
			var s1=Math.abs(that.destination.x-that.source.x),
				s2=Math.abs(that.destination.y-that.source.y),
				globalSpeed=CONFIG.Tower.bubbleSpeed;

			var vx=(globalSpeed*globalSpeed)/(1+(s2*s2)/(s1*s1));
			var vy=s2*vx/s1;
			return {
				vx:vx,
				vy:vy
			}
		};
	var tick=function(){
		//Moving
		var speedObj=calculateSpeed();
		that.x+=speedObj.vx;
		that.y+=speedObj.vy;

		//collistion detection
		//detect Monster collisiion
		var _Monster=that.collisionContainer.Monster
		if( that.x > _Monster.x && that.y > _Monster.y ){
			//This is where collision happens
			_Monster.receive({
				target:that
			});
		}
		//detect Bubble collision
		for(var i=0,len=that.collisionContainer.Bubble.length;i<len;i++){
			var _Bubble=that.collisionContainer.Bubble[i];
			if(that.x > _Bubble.x && that.y > _Bubble.y){
				_Bubble.isDead=true;
			}
		}

		Game.stage.update();

	}
	tick()
}