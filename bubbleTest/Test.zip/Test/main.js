//game world
var Game=(function(){

	var gameworld={
			canvas:document.querySelector("#canvas"),
			level:-1,
			boomNum:0,
			lastTime:0,
			dataCollection:{
				totalkillArmyNum:0
			}
	};



	var 

		 init=function(options){
		 	console.log("Game initializing");

		  
			//load cache if there's got one
			Cache.hasCache() && Cache.loadSession();
	
		}
		,startGame=function(options){
			gameworld.level=options.level||1;

			//load resources


			//init the static element
			_drawBackground({
				level:gameworld.level
			});
			//init the basice modules
			//Bomb
			Bomb.init({
				canvas:gameworld.canvas
			})
			//Timer
			Timer.init({});

			//Some indicator


			//setting button,level indicator,lastTime,boomNum

			//init the placeObject
		}
		,loadCache=function(options){

		}
		,saveSession=function(options){

		}
		,dispose=function(options){

		}
		,_drawBackground=function(options){
			console.log("drawing level " + options.level+" 's background");
			var img=new Image();
				img.src="./img/level"+options.level+".jpg";
			img.onload=function(e){
				var b=new Bitmap(this);
				Game.stage.addChild(b)

			}
		}


	return  {
		stage:new Stage(gameworld.canvas),
		isPlay:true,
		init:init,
		startGame:startGame,
		loadCache:loadCache,
		saveSession:saveSession
	}
})();