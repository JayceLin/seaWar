
//The basic class of the Tower
var Monster=function(options,undefined){
	this.type=options.type;
	this.owner=options.owner;
	

	this.armySize=options.armySize || 0;
	//this.__defineSetter__("armySize",this.updateArmySize);


	this.id=options.id;
	this.status=options.status || "normal";
	this.neighbours=options.neighbours || [];
	this.x=options.x;
    this.y=options.y;


    
	//this.coordinate=options.coordinate;

	 

}
//Monster.prototype=new BitmapAnimation();
Monster.prototype=new Component();



Monster.prototype.updateArmySize=(function(options){
	var sizeIndicator={
		x:this.x+CONFIG.Tower.armySizeIndicator.armySizeOffSetX,
		y:this.y+CONFIG.Tower.armySizeIndicator.armySizeOffSetY
	};

	return {

	}

})();
Monster.prototype.addEventListener=function(options){
	if(options.callback){
		this[options.eventType]=options.callback
	}
	
};

/*//deprecated 
Monster.prototype.loadCoordinate=function(data){
	//load the configration 
	console.log("loading coordinate and place the Object")
};*/
Monster.prototype.shoot=function(options){
	//@@ parameters

	//options.target.num++	
	//this.armySize--

};
Monster.prototype.receive=function(options){
	//@@ parameters
	
	console.log("receive target: ",options.target);
	//this.armySize++
	//update canvas
}

var Tower=function(options){
	Monster.call(this,options)
}

//extend from the Monster
Utility.extend(Tower,Monster);









