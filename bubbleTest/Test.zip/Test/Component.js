
//The Basic of the game Component
var Component=function(options){
	var that=this
	this.tickContainer={
		tick:function(){
			console.log("default tick");
			Game.isPlay && Game.stage.update();
			if(!Game.isPlay){
				that.dispose()
			}
		}
	}
};
Component.prototype=new BitmapAnimation();
/*Component.prototype.defaultTickFun=function(){
	console.log("default tick")
	Game.isPlay && Game.stage.update();
}*/
Component.prototype.init=function(options){
	var that=this;
		this.insideGlobalVariable=options.insideGlobalVariable||{};
	if(options.animations){//this component has animation at the beginning	
			//init Tower Component
			//Tower itself
			var img=new Image();
			img.src=options.imgSrc;
			img.addEventListener("load",function(){
				//console.log("img loaded");
				var spriteSheet=new SpriteSheet({
					images:[this],
					frames:options.frames,
					animations:options.animations
				});
				that.spriteSheet=spriteSheet;
				that.gotoAndPlay(options.startAnimName);
				//that.x=options.x;
				//that.y=options.y;
				that.speed=options.speed || 1;
				that.direction=options.direction || 90;
				that.currentAnimationFrame=options.currentAnimationFrame || 0;

				Game.stage.addChild(that);
				if(options.tickFun){
					that.tickContainer={}
					that.tickContainer.tick=function(){
							console.log("user defined tick")
							Game.isPlay && options.tickFun();
							if(!Game.isPlay){
								that.dispose()
							}
					}
				}
				Ticker.addListener(that.tickContainer);
			},false);

		}
	else{//static component
			var bitmap=new Bitmap(),
				img=new Image();
			img.src=options.imgSrc;
			img.onload=function(){
				bitmap.x=that.x;
				bitmap.y=that.y;
				Game.stage.addChild(bitmap);
				Game.stage.update();
			}
	}
	options.callback && options.callback();
};
Component.prototype.dispose=function(options){
	//remove stage children
	Game.stage.removeChild(this);
	//remove listener
	
	//this.tickContainer["userDefine"] && Ticker.removeListener(this.tickContainer["userDefine"]);
	Ticker.removeListener(this.tickContainer)
};


/*BitmapAnimation.prototype.init=function(){

};
BitmapAnimation.prototype.dispose=function(){

};*/



//Game Component || Modules
var Bomb=(function(){
	return {
		init:function(){
			console.log("bomb initializing");
		}
	}
})();
var Timer=(function(){
	return {
		init:function(){
			console.log("Timer initializing");
		}
	}
})();
var Setting=(function(){

})();


